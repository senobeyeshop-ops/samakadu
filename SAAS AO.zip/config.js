// Valeurs publiques (Supabase > Project Settings > API). La clé anon peut être publique : la sécurité vient des règles RLS.
window.CFG = { url: "https://VOTRE-PROJET.supabase.co", anon: "VOTRE_CLE_ANON" };
